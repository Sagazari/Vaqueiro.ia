# 🎨 GfxGenerator Bot

> Discord bot que gera GFX profissionais de jogos e thumbnails Roblox usando IA — com atualizações ao vivo.

---

## ✨ Comandos

| Comando | Descrição |
|---------|-----------|
| `/gfx` | Gera um GFX ou Thumbnail Roblox com IA |

---

## 🖥️ Preview do progresso

```
⚙️ Iniciando geração...
🎨 Construindo prompt profissional...
📡 Enviando para Hugging Face...
⏳ Modelo carregando... (tentativa 1/5)
🖼️ Renderizando imagem...
✅ Imagem gerada!
📤 Enviando resultado...
```

---

## 🚀 Setup

### 1. Clone e instale
```bash
git clone https://github.com/youruser/gfx-generator.git
cd gfx-generator
npm install
```

### 2. Configure o `.env`
```bash
cp .env.example .env
```
```
DISCORD_TOKEN=seu_token_aqui
CLIENT_ID=seu_client_id_aqui
HF_TOKEN=seu_token_huggingface_aqui
```

### 3. Deploy dos comandos
```bash
npm run deploy
```

### 4. Inicie o bot
```bash
npm start
```

---

## ☁️ Deploy no Railway

1. Suba o projeto no GitHub
2. Acesse [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Adicione as variáveis de ambiente no painel do Railway
4. Deploy automático a cada push! ✅

---

## 🔑 Como obter as chaves

- **Discord Token** → [discord.com/developers](https://discord.com/developers/applications)
- **Hugging Face Token** (grátis) → [huggingface.co](https://huggingface.co) → Settings → Access Tokens

---

## 🤖 Modelo utilizado

`black-forest-labs/FLUX.1-schnell` — Melhor modelo gratuito disponível. Gera imagens 1024x1024 com qualidade excelente.

---

## 📄 License

MIT
