/**
 * services/hfService.js
 * 
 * Hugging Face Inference API — Image Generation
 * Model: black-forest-labs/FLUX.1-schnell (free, high quality)
 */

const fetch = require('node-fetch');
require('dotenv').config();

const HF_TOKEN = process.env.HF_TOKEN;
const MODEL    = 'black-forest-labs/FLUX.1-schnell';
const API_URL  = `https://api-inference.huggingface.co/models/${MODEL}`;

// ── Prompt enhancers per GFX type ──────────────────────────────────────────────

const STYLE_PRESETS = {
  game: {
    prefix: 'epic game artwork, professional game GFX, cinematic lighting, ultra detailed, 4K, dramatic atmosphere,',
    suffix: ', concept art style, vibrant colors, game promotional art, high quality render',
  },
  roblox: {
    prefix: 'Roblox thumbnail art, professional Roblox GFX, blocky characters, vibrant colors, dramatic pose,',
    suffix: ', Roblox game thumbnail style, colorful background, dynamic composition, high quality',
  },
};

/**
 * Generate an image from a prompt.
 * 
 * @param {string} prompt - User's description
 * @param {'game'|'roblox'} style - GFX style preset
 * @param {function} onStep - async callback for live status updates
 * @returns {Promise<Buffer>} - Image buffer
 */
async function generateImage(prompt, style = 'game', onStep = null) {
  const preset      = STYLE_PRESETS[style] || STYLE_PRESETS.game;
  const fullPrompt  = `${preset.prefix} ${prompt} ${preset.suffix}`;
  const negPrompt   = 'blurry, low quality, watermark, text, ugly, deformed, bad anatomy, poorly drawn';

  if (onStep) await onStep('🎨', 'Construindo prompt profissional...');

  const payload = {
    inputs: fullPrompt,
    parameters: {
      negative_prompt: negPrompt,
      num_inference_steps: 4, // FLUX.1-schnell works best with 4 steps
      guidance_scale: 0,      // schnell doesn't use CFG
      width:  1024,
      height: 1024,
    },
  };

  if (onStep) await onStep('📡', 'Enviando para Hugging Face...');

  // Retry loop — model may be loading (cold start)
  let attempts = 0;
  while (attempts < 5) {
    const response = await fetch(API_URL, {
      method:  'POST',
      headers: {
        'Authorization': `Bearer ${HF_TOKEN}`,
        'Content-Type':  'application/json',
      },
      body: JSON.stringify(payload),
    });

    // Model still loading
    if (response.status === 503) {
      attempts++;
      if (onStep) await onStep('⏳', `Modelo carregando... (tentativa ${attempts}/5)`);
      await new Promise(r => setTimeout(r, 8000));
      continue;
    }

    if (!response.ok) {
      const err = await response.text();
      throw new Error(`Hugging Face error ${response.status}: ${err}`);
    }

    if (onStep) await onStep('🖼️', 'Renderizando imagem...');

    const buffer = await response.buffer();
    return buffer;
  }

  throw new Error('O modelo demorou demais para carregar. Tente novamente em alguns segundos.');
}

module.exports = { generateImage };
