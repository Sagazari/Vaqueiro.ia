/**
 * src/deploy.js
 * Run: node src/deploy.js
 */

const { REST, Routes } = require('discord.js');
const fs   = require('fs');
const path = require('path');
require('dotenv').config();

const commands = [];
const files    = fs.readdirSync(path.join(__dirname, 'commands')).filter(f => f.endsWith('.js'));

for (const file of files) {
  const cmd = require(`./commands/${file}`);
  if ('data' in cmd) {
    commands.push(cmd.data.toJSON());
    console.log(`  ✓ ${cmd.data.name}`);
  }
}

const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log(`\n🚀 Deploying ${commands.length} command(s)...`);
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });
    console.log('✅ Done!\n');
  } catch (err) {
    console.error('❌ Failed:', err);
  }
})();
