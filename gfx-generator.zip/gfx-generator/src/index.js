/**
 * src/index.js
 * GfxGenerator Bot — Entry point.
 */

const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs   = require('fs');
const path = require('path');
require('dotenv').config();

const logger = require('./utils/logger');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
client.commands = new Collection();

// ── Load Commands ──────────────────────────────────────────────────────────────
const commandFiles = fs
  .readdirSync(path.join(__dirname, 'commands'))
  .filter(f => f.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  if ('data' in command && 'execute' in command) {
    client.commands.set(command.data.name, command);
    logger.info(`Loaded: ${command.data.name}`);
  }
}

// ── Interaction Handler ────────────────────────────────────────────────────────
client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  const command = client.commands.get(interaction.commandName);
  if (!command) return;
  try {
    await command.execute(interaction);
  } catch (err) {
    logger.error(`Error on /${interaction.commandName}:`, err);
    const msg = { content: '❌ Erro ao executar o comando.', ephemeral: true };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(msg).catch(() => {});
    } else {
      await interaction.reply(msg).catch(() => {});
    }
  }
});

// ── Ready ──────────────────────────────────────────────────────────────────────
client.once('ready', () => {
  logger.info(`✅ GfxGenerator online como ${client.user.tag}`);
  client.user.setActivity('/gfx | GfxGenerator', { type: 3 });
});

client.login(process.env.DISCORD_TOKEN);
