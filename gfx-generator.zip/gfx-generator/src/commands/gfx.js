/**
 * commands/gfx.js
 * 
 * /gfx — Generate professional Game GFX with live status updates.
 */

const {
  SlashCommandBuilder,
  EmbedBuilder,
  AttachmentBuilder,
} = require('discord.js');

const { generateImage } = require('../services/hfService');
const logger            = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gfx')
    .setDescription('Gera um GFX profissional de jogo com IA')
    .addStringOption(opt =>
      opt.setName('prompt')
        .setDescription('Descreva o GFX que quer gerar (ex: warrior knight in dark forest)')
        .setRequired(true))
    .addStringOption(opt =>
      opt.setName('estilo')
        .setDescription('Estilo do GFX')
        .setRequired(false)
        .addChoices(
          { name: '🎮 Game GFX',         value: 'game'   },
          { name: '🟥 Thumbnail Roblox', value: 'roblox' },
        )),

  async execute(interaction) {
    const prompt = interaction.options.getString('prompt');
    const style  = interaction.options.getString('estilo') || 'game';

    const styleLabel = style === 'roblox' ? '🟥 Thumbnail Roblox' : '🎮 Game GFX';

    // ── Initial reply ──────────────────────────────────────────────────────
    await interaction.reply({
      embeds: [buildStatusEmbed(prompt, styleLabel, [])],
    });

    const steps = [];

    const onStep = async (icon, message) => {
      steps.push(`${icon} ${message}`);
      await interaction.editReply({
        embeds: [buildStatusEmbed(prompt, styleLabel, steps)],
      }).catch(() => {});
    };

    try {
      await onStep('⚙️', 'Iniciando geração...');

      const imageBuffer = await generateImage(prompt, style, onStep);

      await onStep('✅', 'Imagem gerada!');
      await onStep('📤', 'Enviando resultado...');

      const attachment = new AttachmentBuilder(imageBuffer, { name: 'gfx.png' });

      const finalEmbed = new EmbedBuilder()
        .setTitle('✅ GFX Gerado!')
        .setColor(0x9b59b6)
        .addFields(
          { name: '📋 Prompt',  value: prompt,     inline: false },
          { name: '🎨 Estilo',  value: styleLabel, inline: true  },
          { name: '📐 Tamanho', value: '1024x1024', inline: true },
        )
        .setImage('attachment://gfx.png')
        .setFooter({ text: 'GfxGenerator • Powered by FLUX.1 via Hugging Face' })
        .setTimestamp();

      await interaction.editReply({
        embeds: [finalEmbed],
        files:  [attachment],
      });

      logger.info(`[GFX] Generated: "${prompt}" (${style})`);

    } catch (err) {
      logger.error('[GFX] Generation failed:', err);

      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Erro na Geração')
        .setColor(0xe74c3c)
        .setDescription(`Ocorreu um erro ao gerar o GFX.\n\`\`\`${err.message}\`\`\``)
        .addFields({ name: '💡 Dica', value: 'Se o modelo estiver carregando, aguarde 30s e tente novamente.', inline: false })
        .setFooter({ text: 'GfxGenerator' });

      await interaction.editReply({ embeds: [errorEmbed] }).catch(() => {});
    }
  },
};

// ── Helpers ────────────────────────────────────────────────────────────────────

function buildStatusEmbed(prompt, styleLabel, steps) {
  const log = steps.length > 0
    ? steps.map((s, i) => i === steps.length - 1 ? `▶ ${s}` : `✔ ${s}`).join('\n')
    : '▶ ⚙️ Iniciando...';

  return new EmbedBuilder()
    .setTitle('🎨 GfxGenerator — Gerando...')
    .setColor(0x9b59b6)
    .addFields(
      { name: '📋 Prompt',  value: prompt,     inline: true },
      { name: '🎨 Estilo',  value: styleLabel, inline: true },
      { name: '📊 Progresso', value: `\`\`\`\n${log}\n\`\`\``, inline: false },
    )
    .setFooter({ text: 'GfxGenerator • Powered by FLUX.1 via Hugging Face' })
    .setTimestamp();
}
