
import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('talkon')
    .setDescription('Ativar Vaqueiro nesse canal'),

  async execute(interaction, ctx) {
    ctx.activeChannels.set(interaction.channel.id, true);
    await interaction.reply('Tô solto aqui agora, visse.');
  }
};
