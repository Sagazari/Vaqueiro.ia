
import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import config from '../config.json' assert { type: "json" };

export default {
  data: new SlashCommandBuilder()
    .setName('info')
    .setDescription('Informações do Vaqueiro'),

  async execute(interaction, ctx) {

    const uptime = Math.floor((Date.now() - ctx.startTime) / 1000);

    const embed = new EmbedBuilder()
      .setColor("#ff8800")
      .setTitle("🤠 Vaqueiro PRO")
      .addFields(
        { name: "Criador", value: config.creator, inline: true },
        { name: "Servidores", value: String(interaction.client.guilds.cache.size), inline: true },
        { name: "Ping", value: interaction.client.ws.ping + "ms", inline: true },
        { name: "Uptime", value: uptime + " segundos", inline: true }
      )
      .setFooter({ text: "Vaqueiro • Versão 3.0.0" });

    await interaction.reply({ embeds: [embed] });
  }
};
