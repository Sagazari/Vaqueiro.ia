
import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('idioma')
    .setDescription('Trocar idioma do Vaqueiro')
    .addStringOption(option =>
      option.setName('lingua')
        .setDescription('Escolha o idioma')
        .setRequired(true)
        .addChoices(
          { name: 'Português', value: 'pt-BR' },
          { name: 'English', value: 'en-US' },
          { name: 'Español', value: 'es-ES' }
        )
    ),

  async execute(interaction, ctx) {
    const nova = interaction.options.getString('lingua');
    ctx.setIdioma(nova);
    await interaction.reply(`Idioma trocado pra ${nova}, cabra.`);
  }
};
