
import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('talkoff')
    .setDescription('Desativar Vaqueiro nesse canal'),

  async execute(interaction, ctx) {
    ctx.activeChannels.delete(interaction.channel.id);
    await interaction.reply('Pronto. Vou ficar quieto aqui agora.');
  }
};
