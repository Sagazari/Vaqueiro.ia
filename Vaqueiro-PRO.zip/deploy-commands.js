
import { REST, Routes } from 'discord.js';
import fs from 'fs';
import dotenv from 'dotenv';
import config from './config.json' assert { type: "json" };

dotenv.config();

const commands = [];
const commandFiles = fs.readdirSync('./commands');

for (const file of commandFiles) {
  const command = (await import(`./commands/${file}`)).default;
  commands.push(command.data.toJSON());
}

const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

await rest.put(
  Routes.applicationCommands(config.clientId),
  { body: commands }
);

console.log('Comandos globais registrados.');
