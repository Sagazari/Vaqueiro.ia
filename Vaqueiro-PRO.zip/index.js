
import { Client, GatewayIntentBits, Collection, EmbedBuilder } from 'discord.js';
import Groq from 'groq-sdk';
import fs from 'fs';
import dotenv from 'dotenv';

dotenv.config();

const startTime = Date.now();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

const groq = new Groq({ apiKey: process.env.GROQ_KEY });

client.commands = new Collection();
const activeChannels = new Map();
const channelMemory = new Map();
const cooldown = new Map();

let idioma = "pt-BR";

// Carregar comandos
const commandFiles = fs.readdirSync('./commands');
for (const file of commandFiles) {
  const command = (await import(`./commands/${file}`)).default;
  client.commands.set(command.data.name, command);
}

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  const command = client.commands.get(interaction.commandName);
  if (command) await command.execute(interaction, {
    activeChannels,
    channelMemory,
    startTime,
    getIdioma: () => idioma,
    setIdioma: (novo) => idioma = novo
  });
});

client.on('messageCreate', async message => {
  if (message.author.bot) return;
  if (!activeChannels.has(message.channel.id)) return;

  const now = Date.now();
  if (cooldown.has(message.author.id) && now - cooldown.get(message.author.id) < 3000) return;
  cooldown.set(message.author.id, now);

  const history = channelMemory.get(message.channel.id) || [];
  history.push({ role: "user", content: message.content });
  if (history.length > 10) history.shift();
  channelMemory.set(message.channel.id, history);

  try {
    const completion = await groq.chat.completions.create({
      model: "llama3-70b-8192",
      messages: [
        {
          role: "system",
          content: `
Tu é Vaqueiro.
Se perguntarem quem tu é, responde que tu é Vaqueiro, cabra da peste.
Nunca diz que é IA.
Nunca pergunta se pode ajudar.
Nada genérico.

Fala nordestino raiz, usa oxente, visse, arretado, cabra da peste, vixe.
Sem formalidade exagerada.
Extremamente inteligente e profissional em qualquer assunto.

Idioma atual: ${idioma}
          `
        },
        ...history
      ]
    });

    const reply = completion.choices[0].message.content;

    history.push({ role: "assistant", content: reply });
    channelMemory.set(message.channel.id, history);

    const embed = new EmbedBuilder()
      .setColor("#ff8800")
      .setAuthor({ name: "🤠 Vaqueiro" })
      .setDescription(reply)
      .setFooter({ text: "Vaqueiro PRO • IA Nordestina" });

    message.reply({ embeds: [embed] });

  } catch (err) {
    console.error(err);
  }
});

client.login(process.env.TOKEN);
